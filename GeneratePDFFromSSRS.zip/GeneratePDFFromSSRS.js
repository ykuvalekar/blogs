quoteInvoice = {
    getReportingSession: function () {

        var selectedIds = Xrm.Page.data.entity.getId();

        selectedIds = selectedIds.replace('{', '').replace('}', '');
        var strParameterXML = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'><entity name= 'quote'><all-attributes/><filter type='and'><condition attribute='quoteid' value='" + selectedIds + "' operator='eq' /></filter></entity></fetch >";
        //var reportGuid = "3EFD9EE3-6B3F-E911-A818-000D3A3B4F42";
        var reportGuid = "9BDD3790-4A3F-E911-A823-000D3A3B4CEE";

        var reportName = "Nu Quotation.rdl";//getReportGuidByName(reportName); //OR Report GUID - Replace with your report GUID
        //var pth = Xrm.Page.context.getClientUrl() + "/CRMReports/rsviewer/QuirksReportViewer.aspx";

        //Added 28th September 2018
        var pth = Xrm.Page.context.getClientUrl() + "/CRMReports/rsviewer/ReportViewer.aspx";
        //End

        var retrieveEntityReq = new XMLHttpRequest();
        retrieveEntityReq.open("POST", pth, false);
        retrieveEntityReq.setRequestHeader("Accept", "*/*");
        retrieveEntityReq.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        retrieveEntityReq.send("id=%7B" + reportGuid + "%7D&uniquename=" + Xrm.Page.context.getOrgUniqueName() + "&iscustomreport=true&reportnameonsrs=&reportName=" + reportName + "&isScheduledReport=false&p:CRM_QuoteId=" + strParameterXML);
        var x = retrieveEntityReq.responseText.lastIndexOf("ReportSession="); var y = retrieveEntityReq.responseText.lastIndexOf("ControlID=");
        var ret = new Array();
        ret[0] = retrieveEntityReq.responseText.substr(x + 14, 24); ret[1] = retrieveEntityReq.responseText.substr(x + 10, 32);
        return ret;
    },
    convertResponseToPDF: function (newPth) {
        //Create query string that will be passed to Report Server to generate PDF version of report response.
        //var pth = Xrm.Page.context.getClientUrl() + "/Reserved.ReportViewerWebControl.axd?ReportSession=" + arrResponseSession[0] + "&Culture=1033&CultureOverrides=True&UICulture=1033&UICultureOverrides=True&ReportStack=1&ControlID=" + arrResponseSession[1] + "&OpType=Export&FileName=Public&ContentDisposition=OnlyHtmlInline&Format=PDF";
        var pth = newPth;

        //Create request object that will be called to convert the response in PDF base 64 string.
        var retrieveEntityReq = new XMLHttpRequest();
        retrieveEntityReq.open("GET", pth, true);
        retrieveEntityReq.setRequestHeader("Accept", "*/*");
        retrieveEntityReq.responseType = "arraybuffer";
        retrieveEntityReq.onreadystatechange = function () { // This is the callback function.
            if (retrieveEntityReq.readyState == 4 && retrieveEntityReq.status == 200) {
                var binary = "";
                var bytes = new Uint8Array(this.response);
                for (var i = 0; i < bytes.byteLength; i++) {
                    binary += String.fromCharCode(bytes[i]);
                }
                //This is the base 64 PDF formatted string and is ready to pass to the action as an input parameter.
                var base64PDFString = btoa(binary);
                //4. Call Action and pass base 64 string as an input parameter. That�s it.
                var entityId = Xrm.Page.data.entity.getId();
                entityId = entityId.replace("{", "").replace("}", "");
                Xrm.Utility.showProgressIndicator("Converted report to PDF. Preparing draft email. Please Wait..");

                quoteInvoice.AddAttachment(entityId, "Quotation.pdf", base64PDFString, function (data) {
                    quoteInvoice.callActionOnButtonClick(data);
                },
                    function (data) {
                        Xrm.Utility.closeProgressIndicator();
                    }
                );
            }
        };
        //This statement sends the request for execution asynchronously. Callback function will be called on completion of the request.
        retrieveEntityReq.send();
    },

    AddAttachment: function (checkinId, fileName, attachmentData, successCallback, errorCallback) {
        //callBacks.Success = successCallback;
        //callBacks.Error = errorCallback;

        if (attachmentData == null) {
            alert("Invalid data sent");
            Xrm.Utility.closeProgressIndicator();
            return;
        }
        if (!quoteInvoice.isGuid(checkinId)) {
            alert("Check In Attribute ID is Invalid GUID.");
            Xrm.Utility.closeProgressIndicator();
            return;
        }

        var inputParams = {
            subject: new Date().toISOString(),
            "filename": fileName,
            "documentbody": attachmentData
        }
        debugger;
        WebAPI.setLookupRequest(checkinId, "quotes", "objectid_quote", inputParams);
        //quoteInvoice.Create("annotations", inputParams, null, successCallback, errorCallback);

        WebAPI.Create("annotations", inputParams, null, successCallback, errorCallback);

    },


    runReportToPrint: function () {
        debugger;

        var params = quoteInvoice.getReportingSession();
        var newPth = Xrm.Page.context.getClientUrl() + "/Reserved.ReportViewerWebControl.axd?ReportSession=" + params[0] + "&Culture=1033&CultureOverrides=True&UICulture=1033&UICultureOverrides=True&ReportStack=1&ControlID=" + params[1] + "&OpType=Export&FileName=public&ContentDisposition=OnlyHtmlInline&Format=PDF";
        quoteInvoice.convertResponseToPDF(newPth);
        //window.open(newPth, "_self");
    },

    callActionOnButtonClick: function (data) {
        debugger;
        var entityId = Xrm.Page.data.entity.getId();
        entityId = entityId.replace("{", "").replace("}", "");

        var parameters = { "noteId": data };

        //// GUID Validation
        if (!quoteInvoice.isGuid(entityId)) {
            alert("ID is Invalid GUID.");
            Xrm.Utility.closeProgressIndicator();
            return;
        }


        WebAPI.invokeBoundAction("quotes", entityId, "nis_SendEmailWitAttachment", parameters, function (result) {
            debugger;
            if (result != null) {
                var activityid = result.emailId;
                Xrm.Utility.closeProgressIndicator();
                Xrm.Utility.openEntityForm("email", activityid);
            }
        });
    },

    isGuid: function (value) {
        /// <summary>
        /// Checks whether value is type of GUID or not.
        /// </summary>
        /// <param name="value" type="type"></param>
        /// <returns type=""></returns>
        var validGuid = new RegExp("^({|()?[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}(}|))?$")
        if (value && typeof value === "string" && validGuid.test(value)) {
            return true;
        }
        return false;
    },

};
function callOnButton() {
    Xrm.Utility.showProgressIndicator("Generating Quote Report. Please Wait..");
    quoteInvoice.runReportToPrint();
}